﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercise2
{
    public partial class Form1 : Form
    {
        ListView myStudents = new ListView();

        public Form1()
        {
            InitializeComponent();
        }

        public Form1(ListView students)
        {
            InitializeComponent();

            foreach (ListViewItem item in students.Items) 
            { 
                myStudents.Items.Add((ListViewItem)item.Clone());
            }
        }

        private void new1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 frm2 = new Form2(myStudents);
            frm2.Show();
        }

        private void info_Click(object sender, EventArgs e)
        {
            //this.Hide();
            Form3 frm3 = new Form3(myStudents);
            frm3.Show();

        }

        private void exit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
