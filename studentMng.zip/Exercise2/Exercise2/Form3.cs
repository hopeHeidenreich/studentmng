﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Exercise2
{
    public partial class Form3 : Form
    {
        public Form3(ListView students)
        {
            InitializeComponent();

            foreach (ListViewItem item in students.Items)
            {
                listView1.Items.Add((ListViewItem)item.Clone());
            }
        }
    }
}
