﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Exercise2
{
    public partial class Form2 : Form
    {
        public Form2(ListView students)
        {
            InitializeComponent();

            foreach (ListViewItem item in students.Items)
            {
                listView1.Items.Add((ListViewItem)item.Clone());
            }
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            txtFname.Clear();
            txtLname.Clear();
            txtEmail.Clear();
            txtPhone.Clear();
            txtAddress.Clear();
            txtState.Clear();
            txtCountry.Clear();
            txtCity.Clear();

            DOB.ResetText();
            DOR.ResetText();

            selectProgram.SelectedIndex = -1;

            radFemale.Checked = false;
            radMale.Checked = false;
            radOther.Checked = false;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string strGender = "";

            if (string.IsNullOrEmpty(txtFname.Text) || string.IsNullOrEmpty(txtLname.Text) || string.IsNullOrEmpty(txtEmail.Text) || string.IsNullOrEmpty(txtPhone.Text) || string.IsNullOrEmpty(selectProgram.SelectedItem.ToString()) || string.IsNullOrEmpty(DOB.Value.ToString()) || string.IsNullOrEmpty(DOR.Value.ToString()) || string.IsNullOrEmpty(txtAddress.Text) || string.IsNullOrEmpty(txtCountry.Text) || string.IsNullOrEmpty(txtState.Text) || string.IsNullOrEmpty(txtCity.Text))
            {
                return;
            }
            else if (radFemale.Checked == false && radMale.Checked == false && radOther.Checked == false)
            {
                return;
            }
            else
            {
                if (radFemale.Checked)
                {
                    strGender = "Female";
                }
                else if (radMale.Checked)
                {
                    strGender = "Male";
                }
                else if (radOther.Checked)
                {
                    strGender = "Other";
                }

                ListViewItem items = new ListViewItem(txtFname.Text);
                items.SubItems.Add(txtLname.Text);
                items.SubItems.Add(txtEmail.Text);
                items.SubItems.Add(txtPhone.Text);
                items.SubItems.Add(DOB.Value.ToString());
                items.SubItems.Add(DOR.Value.ToString());
                items.SubItems.Add(selectProgram.SelectedItem.ToString());
                items.SubItems.Add(txtAddress.Text);
                items.SubItems.Add(strGender);
                items.SubItems.Add(txtCountry.Text);
                items.SubItems.Add(txtState.Text);
                items.SubItems.Add(txtCity.Text);
                listView1.Items.Add(items);

            }

        }

        private void update()
        {
            listView1.SelectedItems[0].SubItems[0].Text = txtFname.Text;
            listView1.SelectedItems[0].SubItems[1].Text = txtLname.Text;
            listView1.SelectedItems[0].SubItems[2].Text = txtEmail.Text;
            listView1.SelectedItems[0].SubItems[3].Text = txtPhone.Text;
            listView1.SelectedItems[0].SubItems[4].Text = DOB.Value.ToString();
            listView1.SelectedItems[0].SubItems[5].Text = DOR.Value.ToString();
            listView1.SelectedItems[0].SubItems[6].Text = selectProgram.SelectedItem.ToString();
            listView1.SelectedItems[0].SubItems[7].Text = txtAddress.Text;
            if (radFemale.Checked)
            {
                listView1.SelectedItems[0].SubItems[8].Text = "Female";
            }
            else if (radMale.Checked)
            {
                listView1.SelectedItems[0].SubItems[8].Text = "Male";
            }
            else if (radOther.Checked)
            {
                listView1.SelectedItems[0].SubItems[8].Text = "Other";
            }
            listView1.SelectedItems[0].SubItems[9].Text = txtCountry.Text;
            listView1.SelectedItems[0].SubItems[10].Text = txtState.Text;
            listView1.SelectedItems[0].SubItems[11].Text = txtCity.Text;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            update();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (listView1.Items.Count > 0)
            {
                listView1.Items.Remove(listView1.SelectedItems[0]);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            var mainForm = new Form1(listView1);
            mainForm.Show();
            this.Hide();
        }


    }
}
