﻿
namespace Exercise2
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listView1 = new System.Windows.Forms.ListView();
            this.name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lname = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.email = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.phone = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dobCol = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dorCol = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.program = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.add = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.gender = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.country = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.state = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.city = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.name,
            this.lname,
            this.email,
            this.phone,
            this.dobCol,
            this.dorCol,
            this.program,
            this.add,
            this.gender,
            this.country,
            this.state,
            this.city});
            this.listView1.FullRowSelect = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(14, 34);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(1178, 207);
            this.listView1.TabIndex = 1;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // name
            // 
            this.name.Text = "Name";
            this.name.Width = 90;
            // 
            // lname
            // 
            this.lname.Text = "Last Name";
            this.lname.Width = 100;
            // 
            // email
            // 
            this.email.Text = "Email";
            this.email.Width = 100;
            // 
            // phone
            // 
            this.phone.Text = "Phone Number";
            this.phone.Width = 100;
            // 
            // dobCol
            // 
            this.dobCol.Text = "DOB";
            // 
            // dorCol
            // 
            this.dorCol.Text = "DOR";
            // 
            // program
            // 
            this.program.Text = "Program";
            this.program.Width = 90;
            // 
            // add
            // 
            this.add.Text = "Address";
            this.add.Width = 150;
            // 
            // gender
            // 
            this.gender.Text = "Gender";
            this.gender.Width = 70;
            // 
            // country
            // 
            this.country.Text = "Country";
            this.country.Width = 80;
            // 
            // state
            // 
            this.state.Text = "State";
            // 
            // city
            // 
            this.city.Text = "City";
            this.city.Width = 67;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1211, 255);
            this.Controls.Add(this.listView1);
            this.Name = "Form3";
            this.Text = "Student Info";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader name;
        private System.Windows.Forms.ColumnHeader lname;
        private System.Windows.Forms.ColumnHeader email;
        private System.Windows.Forms.ColumnHeader phone;
        private System.Windows.Forms.ColumnHeader dobCol;
        private System.Windows.Forms.ColumnHeader dorCol;
        private System.Windows.Forms.ColumnHeader program;
        private System.Windows.Forms.ColumnHeader add;
        private System.Windows.Forms.ColumnHeader gender;
        private System.Windows.Forms.ColumnHeader country;
        private System.Windows.Forms.ColumnHeader state;
        private System.Windows.Forms.ColumnHeader city;
    }
}